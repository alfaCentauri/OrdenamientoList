/*
 * Ordenamiento1.java
 * Ejemplo de ordenamiento de tipos de datos List.
 */
package ordenamiento1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Ejemplo de ordenamiento de tipos de datos List.
 * @author Ricardo Presilla
 */
public class Ordenamiento1 {
    private static final String palos[] =
    { "Corazones", "Diamantes", "Bastos", "Espadas" };
// muestra los elementos del arreglo
    public void imprimirElementos() {
        List< String > lista = Arrays.asList( palos ); // crea objeto List
        // imprime lista
        System.out.printf( "Elementos del arreglo desordenados:\n%s\n", lista );
        Collections.sort( lista ); // ordena ArrayList
        // imprime lista
        System.out.printf( "Elementos del arreglo ordenados:\n%s\n", lista );
    } // fin del método imprimirElementos
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ordenamiento1 orden1 = new Ordenamiento1();
        orden1.imprimirElementos();
    }
    
}
